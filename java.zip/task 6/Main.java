/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc = new Scanner(System.in);
	    int a = sc.nextInt();
	    float b;
		if(a>=0&&a<=50)
		System.out.println("0");
		else if(a>=51&&a<=150){
		    b=((a-50)*3)+((a-50)/5);
		System.out.println(b);
		}
		else if(a>=151&&a<=250){
		    b=((a-50)*5)+((a-50)/5);
		System.out.println(b);
		}
				else {
		    b=((a-50)*7)+((a-50)/5);
		System.out.println(b);
		}
		}
	}

