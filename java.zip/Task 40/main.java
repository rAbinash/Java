import java.util.*;
import add.Add;
public class main
{
public static void main(String[] args)
{
Scanner sc =new Scanner(System.in);
String x=sc.next(),y=sc.next();
Add ad =new Add();
ad.AddElements(x,y);
}
}