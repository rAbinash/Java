/*write a program to print your name in tamil using UNICODE.I take my name as example you can choose yours.

0B85அ,0B86ஆ,0B87இ,0B88ஈ,0B89உ,0B8Aஊ,0B8Eஎ,0B8Fஏ,0B90ஐ,0B92ஒ,0B93ஓ,0B94ஔ,0B95க,0B99ங,
0B9Aச,0B9Cஜ,0B9Eஞ,0B9Fட,0BA3ண,0BA4த,0BA8ந,0BA9ன,0BAAப,0BAEம,0BAFய,0BB0ர,0BB1ற,0BB2ல,0BB3ள,0BB4ழ,0BB5வ,
0BB6ஶ,0BB7ஷ,0BB8ஸ,0BB9ஹ,0BBEா,0BBFி,0BC0ீ,0BC1ு,0BC2ூ,0BC6ெ,0BC7ே,0BC8ை,0BCAொ,0BCBோ,0BCCௌ,0BD0ௐ,0BD7ௗ

use this unicode for tamil.using this unicode add "\u" before.
*/
public class Main
{
	public static void main(String[] args) {
		System.out.println("\u0B85 \u0BAA\u0BBF\u0BA9\u0BBE \u0BB7\u0B82");
	}
}
